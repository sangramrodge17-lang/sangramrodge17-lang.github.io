# Universal Tally Connector

A local Windows bridge between the Universal Tally Accounting Tool and a running TallyPrime installation. It uses TallyPrime's supported local ODBC/XML interfaces and never reads or rewrites `.900` or `.1800` backup files.

## What this first version does

- Runs only on `127.0.0.1`.
- Exposes a small local API on port `17890`.
- Checks Tally's XML endpoint on port `9000`.
- Reads ledgers and balances through the Tally ODBC DSN.
- Provides a read-only SQL endpoint restricted to `SELECT` statements.
- Blocks imports, edits, deletes, and arbitrary write operations.

## Windows installation

1. Install TallyPrime and keep it on the same Windows computer as this connector.
2. Open TallyPrime and enable **ODBC Server** in the connectivity/advanced configuration area. Keep the default HTTP/ODBC port `9000` unless your installation uses another port.
3. Install Python 3.11 or newer.
4. Double-click `install_windows.bat`.
5. Start TallyPrime and then double-click `start_connector.bat`.
6. Keep the connector window running while the web app uses Tally.

To create a single executable after installation, run `build_windows.bat`. The output is `dist\\UniversalTallyConnector.exe`.

## Configuration

The defaults are:

```text
TALLY_HOST=127.0.0.1
TALLY_PORT=9000
TALLY_ODBC_DSN=TallyODBC_9000
TALLY_CONNECTOR_PORT=17890
```

If the local ODBC DSN is different, launch with for example:

```bat
set TALLY_ODBC_DSN=MyTallyDsn
start_connector.bat
```

The connector prints a token when it starts. The web app must send that value as the `X-Tally-Connector-Token` header. Do not publish the token or forward port `17890` to the internet.

## API

Health check, no token required:

```text
GET http://127.0.0.1:17890/health
```

Tally status:

```text
GET /api/tally/status
X-Tally-Connector-Token: <token>
```

Ledger list:

```text
GET /api/ledgers
X-Tally-Connector-Token: <token>
```

Ledger balance:

```text
GET /api/ledger-balance?ledger=HDFC%20Bank
X-Tally-Connector-Token: <token>
```

Read-only custom query:

```text
POST /api/sql
Content-Type: application/json
X-Tally-Connector-Token: <token>

{"sql":"SELECT $Name, $ClosingBalance FROM Ledger"}
```

Only `SELECT` statements are accepted. The connector intentionally has no import endpoint in this release. Voucher creation will require an explicit preview, balancing check, and user confirmation in a later release.

## Known prerequisite

TallyPrime must be running and its ODBC Server must be enabled. The browser cannot load a Windows ODBC driver directly, which is why this local bridge is required.
