@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\pyinstaller.exe (
  echo Run install_windows.bat first.
  pause
  exit /b 1
)
call .venv\Scripts\activate.bat
pyinstaller --noconfirm --clean --onefile --name UniversalTallyConnector tally_connector.py

echo.
echo Built dist\UniversalTallyConnector.exe
pause
