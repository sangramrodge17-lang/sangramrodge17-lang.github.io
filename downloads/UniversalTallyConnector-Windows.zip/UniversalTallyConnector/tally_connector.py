"""Universal Tally Connector.

A local, read-only bridge between a browser application and TallyPrime.
It never reads or modifies .900/.1800 backup files. It talks to the
currently running TallyPrime instance through ODBC and XML/HTTP.

Run on Windows after installing the Tally ODBC driver and pyodbc:
    python tally_connector.py

The browser can call only localhost:17890. Write/import endpoints are
intentionally not implemented in this first release.
"""
from __future__ import annotations

import json
import os
import re
import secrets
import threading
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import parse_qs, urlparse

HOST = "127.0.0.1"
PORT = int(os.getenv("TALLY_CONNECTOR_PORT", "17890"))
TALLY_HOST = os.getenv("TALLY_HOST", "127.0.0.1")
TALLY_PORT = int(os.getenv("TALLY_PORT", "9000"))
TALLY_DSN = os.getenv("TALLY_ODBC_DSN", "TallyODBC_9000")
TOKEN = os.getenv("TALLY_CONNECTOR_TOKEN") or secrets.token_urlsafe(24)

try:
    import pyodbc  # type: ignore
except ImportError:  # pragma: no cover - exercised on a clean Windows install
    pyodbc = None


def json_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def xml_request(payload: str, timeout: float = 8.0) -> str:
    request = urllib.request.Request(
        f"http://{TALLY_HOST}:{TALLY_PORT}",
        data=payload.encode("utf-8"),
        headers={"Content-Type": "text/xml; charset=utf-8"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read().decode("utf-8", errors="replace")


def tally_http_status() -> dict[str, Any]:
    payload = """<ENVELOPE><HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Data</TYPE><ID>Company</ID></HEADER><BODY><DESC><STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT></STATICVARIABLES></DESC></BODY></ENVELOPE>"""
    try:
        body = xml_request(payload, timeout=3)
        return {"connected": True, "transport": "xml", "preview": body[:240]}
    except Exception as exc:
        return {"connected": False, "transport": "xml", "error": str(exc)}


def odbc_connection():
    if pyodbc is None:
        raise RuntimeError("pyodbc is not installed. Run install_windows.bat on the Tally computer.")
    # DSN is the documented TallyPrime pattern. A user can override it with
    # TALLY_ODBC_DSN if their installation uses a different DSN.
    return pyodbc.connect(f"DSN={TALLY_DSN};", timeout=4, autocommit=True)


def run_select(sql: str) -> list[dict[str, Any]]:
    normalized = sql.strip().lower()
    if not normalized.startswith("select "):
        raise ValueError("Only SELECT statements are allowed in read-only mode.")
    if ";" in sql.rstrip(" ;"):
        raise ValueError("Multiple SQL statements are not allowed.")
    if re.search(r"\b(insert|update|delete|drop|alter|create|truncate|exec|execute)\b", normalized):
        raise ValueError("Write or administrative SQL is blocked.")
    with odbc_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(sql)
        columns = [column[0] for column in cursor.description or []]
        return [dict(zip(columns, row)) for row in cursor.fetchall()]


def ledger_balance(ledger: str) -> list[dict[str, Any]]:
    safe = ledger.replace("'", "''")
    return run_select(f"SELECT $Name, $OpeningBalance, $ClosingBalance FROM Ledger WHERE $Name = '{safe}'")


def ledger_list() -> list[dict[str, Any]]:
    return run_select("SELECT $Name, $Parent, $ClosingBalance FROM Ledger")


class Handler(BaseHTTPRequestHandler):
    server_version = "UniversalTallyConnector/0.1"

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"[connector] {self.address_string()} {fmt % args}")

    def authorized(self) -> bool:
        # Browser calls from the same machine may use the one-time token. A
        # token is still required for all non-health endpoints.
        return self.headers.get("X-Tally-Connector-Token", "") == TOKEN

    def send_json(self, status: int, value: Any) -> None:
        body = json_bytes(value)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Tally-Connector-Token")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self) -> None:  # noqa: N802
        self.send_json(204, {})

    def do_GET(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        if path == "/health":
            self.send_json(200, {"service": "Universal Tally Connector", "version": "0.1", "port": PORT, "readOnly": True})
            return
        if not self.authorized():
            self.send_json(401, {"error": "Connector token required"})
            return
        try:
            if path == "/api/tally/status":
                self.send_json(200, tally_http_status())
            elif path == "/api/ledgers":
                self.send_json(200, {"rows": ledger_list(), "transport": "odbc"})
            elif path == "/api/ledger-balance":
                ledger = parse_qs(urlparse(self.path).query).get("ledger", [""])[0]
                if not ledger.strip():
                    raise ValueError("ledger query parameter is required")
                self.send_json(200, {"rows": ledger_balance(ledger), "transport": "odbc"})
            else:
                self.send_json(404, {"error": "Not found"})
        except Exception as exc:
            self.send_json(502, {"error": str(exc), "hint": "Confirm TallyPrime is open, ODBC Server is enabled, and the DSN is correct."})

    def do_POST(self) -> None:  # noqa: N802
        if not self.authorized():
            self.send_json(401, {"error": "Connector token required"})
            return
        path = urlparse(self.path).path
        if path == "/api/sql":
            length = int(self.headers.get("Content-Length", "0"))
            data = json.loads(self.rfile.read(length) or b"{}")
            self.send_json(200, {"rows": run_select(str(data.get("sql", ""))), "transport": "odbc"})
            return
        # No import endpoint exists in the read-only release.
        self.send_json(403, {"error": "Write/import operations are disabled in this connector release."})


def main() -> None:
    print("Universal Tally Connector")
    print(f"Local API: http://{HOST}:{PORT}")
    print(f"Tally endpoint: http://{TALLY_HOST}:{TALLY_PORT}")
    print(f"ODBC DSN: {TALLY_DSN}")
    print("Read-only mode: enabled")
    print(f"Connector token (save for the web app): {TOKEN}")
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()


if __name__ == "__main__":
    main()
