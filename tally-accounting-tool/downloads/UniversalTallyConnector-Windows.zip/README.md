# Universal Tally Connector v2.6.0

A local Windows bridge between the Universal Tally Accounting Tool and a running TallyPrime installation. It uses TallyPrime's supported local XML/ODBC interfaces and keeps company data on the same Windows computer.

## What v2.6.0 does

- Runs only on `127.0.0.1` and exposes the local API on port `17891`.
- Checks TallyPrime's XML endpoint on port `9000`.
- Reads the complete ledger list, requested ledger balances, date-aware Trial Balance reports, and ledger voucher history.
- Adds a token-protected `POST /api/ai-answer` route for local Gemini answers.
- Receives the Gemini key from the local browser session only; GitHub Pages never receives the key.
- Provides preview-first ledger create/alter requests that require explicit confirmation.
- Sanitizes malformed Tally XML control characters and retains a tolerant fallback parser.

## Windows installation

1. Install TallyPrime and keep it on the same Windows computer as this connector.
2. Open TallyPrime and enable its HTTP/ODBC server. Keep the default Tally port `9000` unless your installation uses another port.
3. Download and run `UniversalTallyConnector-v2.6.0.exe`.
4. Copy the pairing token shown in the connector window into Tally Chat.
5. Paste your Google AI Studio Gemini API key into the **Gemini API key — Local only** field in Tally Chat.
6. Keep the connector window running while the web app uses Tally.

The Gemini key is sent only to `127.0.0.1:17891` and is not stored by the website. Do not publish the key or forward port `17891` to the internet.

## API

Health check, no token required:

```text
GET http://127.0.0.1:17891/health
```

The following routes require `X-Tally-Connector-Token: <token>`:

```text
GET  /api/tally/status
GET  /api/ledgers
GET  /api/ledger-balance?ledger=HDFC%20Bank
GET  /api/trial-balance?to=20260331
GET  /api/ledger-entries?ledger=HDFC%20Bank
POST /api/ai-answer
```

Ledger writes are preview-first. The connector will not change TallyPrime without a separate request with explicit confirmation.

## Prerequisite

TallyPrime must be running and its HTTP/ODBC server must be enabled. The browser cannot load a Windows ODBC driver directly, which is why this local bridge is required.
